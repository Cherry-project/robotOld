Here the vision part of the project, develop by adil.

Goals :
